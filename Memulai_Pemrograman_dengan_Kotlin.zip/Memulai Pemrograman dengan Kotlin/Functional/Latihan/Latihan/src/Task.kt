fun main() {
    val text = "Kotlin".getFirstAndLast()

    val firstChar = text["first"]
    val lastChar = text["last"]

    // TODO 2
    println()

}

// TODO 1
fun String.getFirstAndLast() = mapOf<String, Char>()